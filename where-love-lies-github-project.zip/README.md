# WHERE LOVE LIES — 3D Animated Story Starter

A browser-based 3D storybook/trailer starter made with Three.js. It contains eight scenes and scene captions based on your story. Characters and scenery are stylized primitive 3D models (not finished studio-quality character assets).

## Run locally
Because `main.js` imports Three.js modules, run from a local web server:
- Python: `python -m http.server 8000`
- Open `http://localhost:8000`

## Publish on GitHub Pages
1. Create a GitHub repository named `where-love-lies`.
2. Upload `index.html`, `style.css`, and `main.js` (and this README).
3. In repository Settings → Pages, choose deploy from branch `main`, folder `/ (root)`.
4. Wait for GitHub Pages to publish and open its URL.

The project loads Three.js from a CDN, so an internet connection is needed. This is a starter visual prototype, not a rendered full-length film or voice-acted production.
