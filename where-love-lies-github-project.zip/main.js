import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const scene=new THREE.Scene(); scene.background=new THREE.Color(0x7c9ed0); scene.fog=new THREE.Fog(0x7c9ed0,22,65);
const camera=new THREE.PerspectiveCamera(55,innerWidth/innerHeight,.1,100); camera.position.set(0,6,15);
const renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setSize(innerWidth,innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; document.body.appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement); controls.enableDamping=true; controls.target.set(0,2,0);
scene.add(new THREE.HemisphereLight(0xffe8c7,0x35405b,2));
const sun=new THREE.DirectionalLight(0xffd38a,3); sun.position.set(-7,12,8); sun.castShadow=true; scene.add(sun);
const mat=(color,roughness=.8)=>new THREE.MeshStandardMaterial({color,roughness});
const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,100),mat(0x3e7148)); ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
function box(x,y,z,sx,sy,sz,color){const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat(color));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m}
function sphere(x,y,z,r,color){const m=new THREE.Mesh(new THREE.SphereGeometry(r,24,16),mat(color));m.position.set(x,y,z);m.castShadow=true;scene.add(m);return m}
function tree(x,z){box(x,1,z,.45,2,.45,0x69442b);sphere(x,2.7,z,1.35,0x24613d);sphere(x-.7,2.3,z+.2,.8,0x347b43)}
for(let i=0;i<18;i++){tree((i%6-3)*5,Math.floor(i/6)*-6-7)}
// Royal palace: colorful walls, towers and gold roofs
box(0,2,-13,13,4,3,0xd8b57a); for(let x of [-5,0,5]){box(x,4.2,-13,2,4.4,2,0xe7c58b);const roof=new THREE.Mesh(new THREE.ConeGeometry(1.6,2,4),mat(0xb57a2a));roof.position.set(x,7.4,-13);roof.rotation.y=Math.PI/4;scene.add(roof)}
// river strip
const river=new THREE.Mesh(new THREE.PlaneGeometry(32,5),new THREE.MeshStandardMaterial({color:0x3a9bc3,roughness:.25,metalness:.2}));river.rotation.x=-Math.PI/2;river.position.set(0,.03,5);scene.add(river);
// Characters made of stylized 3D primitives. Colors / roles remain consistent.
function person(name,x,z,skin,cloth,scale=1,crown=false){const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);scene.add(g);
const body=new THREE.Mesh(new THREE.CylinderGeometry(.55,.75,1.8,16),mat(cloth));body.position.y=1.5;body.castShadow=true;g.add(body);
const head=new THREE.Mesh(new THREE.SphereGeometry(.58,24,18),mat(skin));head.position.y=2.8;head.castShadow=true;g.add(head);
const hair=new THREE.Mesh(new THREE.SphereGeometry(.61,20,12,0,Math.PI*2,0,Math.PI*.55),mat(0x21150f));hair.position.y=3.05;g.add(hair);
const eyesMat=mat(0x17120e);for(let dx of [-.2,.2]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.06,8,8),eyesMat);eye.position.set(dx,2.83,.52);g.add(eye)}
if(crown){const ring=new THREE.Mesh(new THREE.TorusGeometry(.48,.09,8,24),mat(0xf4c542));ring.position.y=3.35;ring.rotation.x=Math.PI/2;g.add(ring)}
g.userData.role=name;return g}
const yando=person('Yando',-2,1,0x8b4c2d,0x9c2871,1,true);
const ziah=person('Ziah',2,1,0x754027,0x365c42,1,false);
const king=person('King Kpoto',-5,-8,0x704027,0x8b1e25,1.15,true);
const blay=person('Prince Blay',5,-8,0x824b2e,0x233b78,1.1,true);
const witch=person('Gbeh',0,-18,0x4d3027,0x241a35,1.25,false);
witch.visible=false; yando.visible=false; ziah.visible=false; king.visible=false; blay.visible=false;
const scenes=[
{title:'BALU TOWN',caption:'In the great land of Balu Town, fishing and tradition shaped the lives of its people. Princess Yando grew up surrounded by royal comfort, yet her heart longed for freedom.',show:['yando','king'],cam:[0,6,13],target:[0,2,-4]},
{title:'THE FOREST MEETING',caption:'One day, a hunter’s trap caught Yando in the abandoned forest. Ziah, a kind young hunter, rescued her. Their unexpected meeting sparked a connection neither could forget.',show:['yando','ziah'],cam:[0,5,9],target:[0,2,0]},
{title:'A LOVE THAT BLOOMS',caption:'At the village square, Yando and Ziah met again. Beneath a palm tree, friendship grew into a love that challenged the rules of the royal palace.',show:['yando','ziah'],cam:[0,5,10],target:[0,2,0]},
{title:'THE ARRIVAL OF PRINCE BLAY',caption:'King Kpoto arranged Yando’s marriage to Prince Blay. Polite in public, Blay secretly dreamed of controlling the kingdom—and the princess.',show:['yando','king','blay'],cam:[0,7,17],target:[0,3,-8]},
{title:'THE WITCH’S REVENGE',caption:'On the wedding day, Gbeh returned to avenge an old tragedy. With dark magic, she took Yando and demanded a brave champion face her trials.',show:['yando','king','blay','witch'],cam:[0,7,16],target:[0,2,-7]},
{title:'ZIAH’S JOURNEY',caption:'Across Ropo River, Dulcahn Village, Dahtokehn Town, Wloplukehn Village, and Mount Gbakehn, Ziah faced temptation, danger, and a beast—never abandoning his promise.',show:['ziah','witch'],cam:[0,6,12],target:[0,2,-5]},
{title:'THE SECRET REVEALED',caption:'At the mountain palace, Gbeh revealed Ziah was a prince. Yando embraced him—not for his royal blood, but because she loved him before she knew his identity.',show:['yando','ziah','witch'],cam:[0,5,9],target:[0,2,-5]},
{title:'A HAPPY ENDING',caption:'Ziah defeated the witch and brought Yando home. King Kpoto welcomed their love, and the kingdom celebrated their wedding. Their story became a legend of courage and true love.',show:['yando','ziah','king'],cam:[0,6,13],target:[0,2,-4]}
];
let idx=0;const refs={yando,ziah,king,blay,witch};
function update(){const s=scenes[idx];document.querySelector('#chapter').textContent=s.title;document.querySelector('#caption').textContent=s.caption;document.querySelector('#counter').textContent=`Scene ${idx+1} / ${scenes.length}`;
Object.values(refs).forEach(o=>o.visible=false);s.show.forEach(n=>refs[n].visible=true);
camera.position.set(...s.cam);controls.target.set(...s.target);controls.update()}
document.querySelector('#prev').onclick=()=>{idx=(idx-1+scenes.length)%scenes.length;update()};
document.querySelector('#next').onclick=()=>{idx=(idx+1)%scenes.length;update()};
let playing=false,timer;document.querySelector('#play').onclick=()=>{playing=!playing;document.querySelector('#play').textContent=playing?'❚❚ Pause':'▶ Play story';if(playing){timer=setInterval(()=>{idx=(idx+1)%scenes.length;update()},6500)}else clearInterval(timer)};
update();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
function animate(){requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)}animate();
